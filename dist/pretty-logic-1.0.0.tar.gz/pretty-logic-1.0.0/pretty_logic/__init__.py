from pretty_logic.pretty_logic import _or, _and
